"""
Fuzzy Logic Intrusion Detection System (Mamdani + Sugeno) on NSL-KDD.
Run with:   streamlit run app.py
Only fuzzy logic is used (no machine learning). Everything lives in this one file.
"""
import copy
import json
import os
import time

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# =============================================================================
# 1. CONSTANTS: dataset columns, attack families
# =============================================================================
BASE = os.path.dirname(os.path.abspath(__file__))
TRAIN_PATH = os.path.join(BASE, "data", "KDDTrain_.txt")
TEST_PATH = os.path.join(BASE, "data", "KDDTest_.txt")

COLUMNS = [
    "duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes", "land",
    "wrong_fragment", "urgent", "hot", "num_failed_logins", "logged_in", "num_compromised",
    "root_shell", "su_attempted", "num_root", "num_file_creations", "num_shells",
    "num_access_files", "num_outbound_cmds", "is_host_login", "is_guest_login", "count",
    "srv_count", "serror_rate", "srv_serror_rate", "rerror_rate", "srv_rerror_rate",
    "same_srv_rate", "diff_srv_rate", "srv_diff_host_rate", "dst_host_count",
    "dst_host_srv_count", "dst_host_same_srv_rate", "dst_host_diff_srv_rate",
    "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate", "dst_host_serror_rate",
    "dst_host_srv_serror_rate", "dst_host_rerror_rate", "dst_host_srv_rerror_rate",
    "label", "difficulty",
]

# Standard NSL-KDD grouping of the attack names into 4 families
FAMILY = {}
for _name in "back land neptune pod smurf teardrop apache2 udpstorm processtable worm mailbomb".split():
    FAMILY[_name] = "DoS"
for _name in "ipsweep nmap portsweep satan mscan saint".split():
    FAMILY[_name] = "Probe"
for _name in "buffer_overflow loadmodule perl rootkit httptunnel ps sqlattack xterm".split():
    FAMILY[_name] = "U2R"
for _name in ("ftp_write guess_passwd imap multihop phf spy warezclient warezmaster "
              "snmpguess snmpgetattack named xlock xsnoop sendmail").split():
    FAMILY[_name] = "R2L"

# Neon palette
CYAN, BLUE, PURPLE = "#00f5ff", "#3b82f6", "#a855f7"
GREEN, AMBER, RED = "#22ffaa", "#ffb020", "#ff3b6b"
CLASS_COLORS = {"Normal": GREEN, "Suspicious": AMBER, "Malicious": RED}
CLASSES = ["Normal", "Suspicious", "Malicious"]


# =============================================================================
# 2. FUZZY INPUT VARIABLES (selected from the dataset analysis)
# =============================================================================
# Every input is first scaled to the range 0..1 (min-max with a cap).
#   cap   : value that maps to 1.0 (larger values are clipped = outlier handling)
#   log   : True -> log10(1+x) is used before scaling (byte counts are very skewed)
# All membership functions below are defined on this normalised 0..1 scale.
VARIABLES = {
    "serror_rate": dict(label="SYN-error rate", cap=1.0, log=False,
                        info="share of connections with SYN errors (flooding / DoS)"),
    "rerror_rate": dict(label="REJ-error rate", cap=1.0, log=False,
                        info="share of connections rejected (port scanning / probing)"),
    "count": dict(label="Connections to same host", cap=511, log=False,
                  info="connections to the same host in the last 2 seconds"),
    "same_srv_rate": dict(label="Same-service rate", cap=1.0, log=False,
                          info="share of those connections that used the same service"),
    "diff_srv_rate": dict(label="Different-service rate", cap=1.0, log=False,
                          info="share of those connections that used different services (scan)"),
    "dst_host_srv_count": dict(label="Dest-host service count", cap=255, log=False,
                               info="connections to the same service on the destination host"),
    "logged_in": dict(label="Logged in", cap=1.0, log=False,
                      info="1 = login succeeded (real sessions), 0 = no login"),
    "dst_host_count": dict(label="Dest-host connection count", cap=255, log=False,
                           info="connections to the destination host (low = one-shot sweeps across many hosts)"),
    "src_bytes": dict(label="Source bytes", cap=1e7, log=True,
                      info="bytes sent from source to destination (log scale)"),
}
# type, parameters.  tri=[a,b,c]  trap=[a,b,c,d]  gauss=[mean,sigma]
DEFAULT_MF = {
    "serror_rate": {"low": ("trap", [0, 0, 0.05, 0.30]), "medium": ("tri", [0.15, 0.5, 0.85]),
                    "high": ("trap", [0.60, 0.85, 1, 1])},
    "rerror_rate": {"low": ("trap", [0, 0, 0.05, 0.30]), "medium": ("tri", [0.15, 0.5, 0.85]),
                    "high": ("trap", [0.50, 0.80, 1, 1])},
    "count": {"low": ("trap", [0, 0, 0.02, 0.08]), "medium": ("gauss", [0.12, 0.07]),
              "high": ("trap", [0.15, 0.40, 1, 1]), "very_high": ("trap", [0.50, 0.85, 1, 1])},
    "same_srv_rate": {"low": ("trap", [0, 0, 0.30, 0.60]), "medium": ("tri", [0.40, 0.65, 0.90]),
                      "high": ("trap", [0.70, 0.95, 1, 1])},
    "diff_srv_rate": {"low": ("trap", [0, 0, 0.03, 0.15]), "medium": ("tri", [0.05, 0.20, 0.40]),
                      "high": ("trap", [0.20, 0.45, 1, 1])},
    "dst_host_srv_count": {"low": ("trap", [0, 0, 0.10, 0.30]), "medium": ("tri", [0.15, 0.45, 0.80]),
                           "high": ("trap", [0.60, 0.90, 1, 1])},
    "dst_host_count": {"low": ("trap", [0, 0, 0.02, 0.10]), "high": ("trap", [0.30, 0.80, 1, 1])},
    "logged_in": {"no": ("trap", [0, 0, 0.30, 0.60]), "yes": ("trap", [0.40, 0.70, 1, 1])},
    "src_bytes": {"tiny": ("trap", [0, 0, 0.12, 0.20]), "normal": ("tri", [0.15, 0.40, 0.65]),
                  "huge": ("trap", [0.55, 0.75, 1, 1])},
}
# Output (risk score 0..100) fuzzy sets used by the Mamdani system
OUT_MF = {"Low": ("trap", [0, 0, 15, 40]), "Medium": ("tri", [25, 50, 75]),
          "High": ("trap", [60, 85, 100, 100])}
UNIVERSE = np.arange(0, 101, 1.0)          # discretised risk axis for centroid


# =============================================================================
# 3. THE FUZZY RULE BASE
# =============================================================================
# Each rule:  IF <conditions joined by AND/OR> THEN risk is <Mamdani set> (Mamdani)
#                                                   THEN risk = <constant>  (Sugeno, zero-order)
# 'why' explains the cyber-security meaning of the rule.
def R(rid, cond, mam, sug, why, op="AND", weight=1.0):
    return dict(id=rid, cond=cond, op=op, mam=mam, sug=float(sug), why=why,
                weight=weight, enabled=True)


DEFAULT_RULES = [
    # ---- evidence of NORMAL traffic -------------------------------------------------
    R("N1", [("logged_in", "yes"), ("serror_rate", "low"), ("same_srv_rate", "high")], "Low", 5,
      "A completed login with clean TCP handshakes and one steady service is typical user activity."),
    R("N2", [("serror_rate", "low"), ("rerror_rate", "low"), ("diff_srv_rate", "low"), ("count", "low")],
      "Low", 10, "Few connections, no handshake or reject errors and no service hopping: quiet normal traffic."),
    R("N3", [("logged_in", "yes"), ("dst_host_srv_count", "high"), ("serror_rate", "low")], "Low", 8,
      "A busy, healthy service that many authenticated users share (web / mail / ftp)."),
    R("N4", [("logged_in", "no"), ("same_srv_rate", "high"), ("dst_host_srv_count", "high"),
             ("serror_rate", "low"), ("rerror_rate", "low"), ("count", "low")], "Low", 20,
      "Short lookups (DNS / ping) to a popular service with no errors and a small connection count. "
      "Weight 0.7 because some ping sweeps look similar.", weight=0.7),
    R("N5", [("logged_in", "no"), ("same_srv_rate", "high"), ("dst_host_srv_count", "high"),
             ("serror_rate", "low"), ("rerror_rate", "low"), ("count", "medium")], "Low", 15,
      "Moderate bursts of clean lookups to a popular service: ordinary name-server / web-browsing activity."),
    R("N6", [("rerror_rate", "high"), ("count", "low"), ("dst_host_srv_count", "high")], "Low", 20,
      "A single rejected connection to a popular web service is a normal closed-port or timeout event."),
    R("B1", [("serror_rate", "low"), ("rerror_rate", "low")], "Low", 20,
      "Baseline: no handshake or reject errors means no flood/scan evidence. Low weight so it never hides other rules.", weight=0.4),
    # ---- DoS / flooding -------------------------------------------------------------
    R("D1", [("serror_rate", "high"), ("count", "high")], "High", 97,
      "Many connections that never complete the TCP handshake: SYN flood (neptune)."),
    R("D2", [("serror_rate", "high"), ("same_srv_rate", "low")], "High", 94,
      "SYN errors spread over random services/ports: spoofed flood traffic."),
    R("D3", [("serror_rate", "high"), ("logged_in", "no")], "High", 92,
      "Handshake failures with no login: nobody is really using the service."),
    R("D4", [("count", "very_high"), ("logged_in", "no"), ("src_bytes", "normal")], "High", 90,
      "Extreme connection bursts to one host with identical payload sizes and no login: smurf / ICMP flood."),
    # ---- Probe / scanning -----------------------------------------------------------
    R("P1", [("diff_srv_rate", "high"), ("rerror_rate", "high")], "High", 92,
      "Many different services hit and rejected: port scan (satan, portsweep)."),
    R("P2", [("rerror_rate", "high"), ("count", "high")], "High", 85,
      "A burst of rejected connections: attacker probing closed ports."),
    R("P3", [("diff_srv_rate", "high"), ("count", "high")], "High", 85,
      "Fast service hopping inside a short time window: scanning tool at work."),
    R("P4", [("src_bytes", "tiny"), ("logged_in", "no"), ("dst_host_count", "low")], "Medium", 70,
      "Empty probe packets, each to a different host, no login: ping sweep (ipsweep, nmap)."),
    R("P5", [("rerror_rate", "high"), ("dst_host_srv_count", "low")], "Medium", 62,
      "Rejects against a service that is almost unused: probing for open ports."),
    # ---- Suspicious sessions --------------------------------------------------------
    R("S1", [("logged_in", "yes"), ("src_bytes", "huge")], "Medium", 45,
      "Authenticated session pushing an unusually large upload: possible data planting or a bulk transfer to review."),
    R("S2", [("same_srv_rate", "low"), ("count", "high"), ("logged_in", "no")], "Medium", 65,
      "Many services touched in a burst without logging in: reconnaissance."),
]


# =============================================================================
# 4. MEMBERSHIP FUNCTIONS
# =============================================================================
def membership(kind, p, x):
    """Membership degree (0..1) of the values x for one fuzzy set."""
    x = np.asarray(x, dtype=float)
    if kind == "tri":                      # triangular  [a, b, c]
        a, b, c = p
        left = (x - a) / (b - a) if b > a else (x >= b).astype(float)
        right = (c - x) / (c - b) if c > b else (x <= b).astype(float)
        return np.clip(np.minimum(left, right), 0, 1)
    if kind == "trap":                     # trapezoidal [a, b, c, d]
        a, b, c, d = p
        left = (x - a) / (b - a) if b > a else np.ones_like(x)
        right = (d - x) / (d - c) if d > c else np.ones_like(x)
        return np.clip(np.minimum(np.minimum(left, 1), right), 0, 1)
    if kind == "gauss":                    # Gaussian [mean, sigma]
        m, s = p
        return np.exp(-((x - m) ** 2) / (2 * max(s, 1e-6) ** 2))
    raise ValueError("unknown membership type " + str(kind))


# =============================================================================
# 5. DATA LOADING AND PREPROCESSING
# =============================================================================
@st.cache_data(show_spinner=False)
def load_dataset(path):
    df = pd.read_csv(path, header=None, names=COLUMNS)
    df["attack_name"] = df["label"].str.strip().str.lower()
    df["actual"] = np.where(df["attack_name"] == "normal", "Normal", "Attack")
    df["family"] = df["attack_name"].map(lambda n: "Normal" if n == "normal" else FAMILY.get(n, "Other"))
    return df


def split_feature_types(df):
    """Detect numerical / categorical features automatically (not hard-coded)."""
    skip = {"label", "attack_name", "actual", "family", "difficulty"}
    cols = [c for c in df.columns if c not in skip]
    cat = [c for c in cols if df[c].dtype == object or str(df[c].dtype).startswith("str")]
    num = [c for c in cols if c not in cat]
    return num, cat


def data_quality(df):
    return dict(rows=len(df), missing=int(df.isna().sum().sum()), duplicates=int(df.duplicated().sum()),
                negatives=int((df.select_dtypes("number") < 0).sum().sum()))


def feature_relevance(df):
    """Single-feature AUC on the TRAINING data: how well one feature alone separates attacks.
    Relevance = |AUC - 0.5| * 2   (0 = useless, 1 = perfect)."""
    y = (df["actual"] == "Attack").values
    n1, n0 = y.sum(), (~y).sum()
    rows = []
    for c in split_feature_types(df)[0]:
        if df[c].nunique() < 2:
            rows.append((c, 0.5, 0.0))
            continue
        ranks = df[c].rank().values
        auc = (ranks[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
        rows.append((c, auc, abs(auc - 0.5) * 2))
    out = pd.DataFrame(rows, columns=["feature", "auc", "relevance"]).sort_values("relevance", ascending=False)
    out["used_in_fuzzy_model"] = out["feature"].isin(VARIABLES)
    return out.reset_index(drop=True)


def fit_medians(train_df):
    return {v: float(train_df[v].median()) for v in VARIABLES}


def preprocess(df, medians):
    """Raw records -> normalised fuzzy inputs (0..1). Same function is used for both models.
    Steps: numeric conversion, replace missing/invalid with TRAIN median, clip outliers, scale."""
    out = pd.DataFrame(index=df.index)
    report = dict(missing_filled=0, invalid_fixed=0, clipped=0)
    for v, cfg in VARIABLES.items():
        if v in df.columns:
            raw = pd.to_numeric(df[v], errors="coerce")
        else:
            raw = pd.Series(np.nan, index=df.index)
        bad = raw.isna() | np.isinf(raw)
        report["missing_filled"] += int(bad.sum())
        raw = raw.mask(bad, medians[v])
        neg = raw < 0
        report["invalid_fixed"] += int(neg.sum())
        raw = raw.mask(neg, 0)
        over = raw > cfg["cap"]
        report["clipped"] += int(over.sum())
        raw = raw.clip(upper=cfg["cap"])
        if cfg["log"]:
            out[v] = np.log10(1 + raw) / np.log10(1 + cfg["cap"])
        else:
            out[v] = raw / cfg["cap"]
    return out, report


def fuzzify(xn, mfs):
    """Membership degrees of every fuzzy set: dict[(variable,set)] -> array"""
    return {(v, s): membership(k, p, xn[v].values) for v, sets in mfs.items() for s, (k, p) in sets.items()}


# =============================================================================
# 6. THE TWO FUZZY INFERENCE SYSTEMS
# =============================================================================
def rule_strength(rule, mu, how):
    """Firing strength of one rule.
    Mamdani: AND = min, OR = max            Sugeno: AND = product, OR = probabilistic sum"""
    parts = [mu[(v, s)] for v, s in rule["cond"]]
    f = parts[0].copy()
    for m in parts[1:]:
        if how == "mamdani":
            f = np.minimum(f, m) if rule["op"] == "AND" else np.maximum(f, m)
        else:
            f = f * m if rule["op"] == "AND" else f + m - f * m
    return f * rule["weight"] if rule["enabled"] else np.zeros_like(f)


def mamdani_infer(xn, mfs, rules, out_mf=OUT_MF, return_agg=False):
    """Mamdani: fuzzify -> min/max rules -> min IMPLICATION (clip output set) ->
    max AGGREGATION -> CENTROID defuzzification.  Returns (risk 0..100, firing matrix)."""
    mu = fuzzify(xn, mfs)
    fire = np.column_stack([rule_strength(r, mu, "mamdani") for r in rules])      # (N, rules)
    n = len(xn)
    aggregated = np.zeros((n, len(UNIVERSE)))
    for label, (k, p) in out_mf.items():
        idx = [i for i, r in enumerate(rules) if r["mam"] == label]
        if not idx:
            continue
        strength = np.clip(fire[:, idx].max(axis=1), 0, 1)                       # strongest rule for this label
        clipped = np.minimum(strength[:, None], membership(k, p, UNIVERSE)[None, :])   # implication = min
        aggregated = np.maximum(aggregated, clipped)                             # aggregation = max
    area = aggregated.sum(axis=1)
    risk = np.where(area > 1e-9, (aggregated * UNIVERSE).sum(axis=1) / np.maximum(area, 1e-9), 50.0)
    if return_agg:
        return risk, fire, aggregated
    return risk, fire


def sugeno_infer(xn, mfs, rules):
    """Zero-order Sugeno: AND = product -> rule output is a constant z_k ->
    WEIGHTED AVERAGE  sum(w_k*z_k)/sum(w_k).  No output membership functions, no centroid."""
    mu = fuzzify(xn, mfs)
    fire = np.column_stack([rule_strength(r, mu, "sugeno") for r in rules])
    z = np.array([r["sug"] for r in rules])
    total = fire.sum(axis=1)
    risk = np.where(total > 1e-9, (fire * z).sum(axis=1) / np.maximum(total, 1e-9), 50.0)
    return np.clip(risk, 0, 100), fire


def classify(score, t_normal, t_malicious):
    return np.where(score < t_normal, "Normal", np.where(score < t_malicious, "Suspicious", "Malicious"))


def run_models(df, medians, mfs, rules):
    """Run BOTH models on raw records; returns result frame and the two firing matrices."""
    xn, rep = preprocess(df, medians)
    t0 = time.perf_counter()
    m_score, m_fire = mamdani_infer(xn, mfs, rules)
    t1 = time.perf_counter()
    s_score, s_fire = sugeno_infer(xn, mfs, rules)
    t2 = time.perf_counter()
    res = pd.DataFrame({"mamdani_risk": m_score, "sugeno_risk": s_score}, index=df.index)
    timing = dict(mamdani_ms_per_1000=(t1 - t0) / max(len(df), 1) * 1e6,
                  sugeno_ms_per_1000=(t2 - t1) / max(len(df), 1) * 1e6)
    return res, m_fire, s_fire, rep, timing


# =============================================================================
# 7. EVALUATION HELPERS (written by hand: confusion matrix, metrics, ROC, AUC)
# =============================================================================
def split_train(train_df, seed=42, fit_fraction=0.7):
    """Fixed split of the TRAINING file: 'fit' part for studying the rules, 'val' part for threshold
    tuning. The official test file is never used for any tuning (no data leakage)."""
    order = np.random.RandomState(seed).permutation(len(train_df))
    cut = int(fit_fraction * len(train_df))
    return train_df.iloc[order[:cut]], train_df.iloc[order[cut:]]


def confusion(y, pred):
    y, pred = np.asarray(y).astype(bool), np.asarray(pred).astype(bool)
    return dict(TP=int((y & pred).sum()), TN=int((~y & ~pred).sum()),
                FP=int((~y & pred).sum()), FN=int((y & ~pred).sum()))


def metrics_from(c):
    tp, tn, fp, fn = c["TP"], c["TN"], c["FP"], c["FN"]
    div = lambda a, b: a / b if b else 0.0
    prec, rec = div(tp, tp + fp), div(tp, tp + fn)
    return dict(Accuracy=div(tp + tn, tp + tn + fp + fn), Precision=prec, Recall=rec,
                F1=div(2 * prec * rec, prec + rec), Specificity=div(tn, tn + fp),
                FPR=div(fp, fp + tn), FNR=div(fn, fn + tp))


def roc_curve(y, score):
    """Return fpr, tpr, auc computed from the continuous risk score."""
    y = np.asarray(y).astype(int)
    order = np.argsort(-score, kind="stable")
    ys, ss = y[order], np.asarray(score)[order]
    tps, fps = np.cumsum(ys), np.cumsum(1 - ys)
    keep = np.r_[np.where(np.diff(ss) != 0)[0], len(ss) - 1]          # one point per distinct score
    tpr = np.r_[0, tps[keep] / max(tps[-1], 1)]
    fpr = np.r_[0, fps[keep] / max(fps[-1], 1)]
    auc = float(np.sum((fpr[1:] - fpr[:-1]) * (tpr[1:] + tpr[:-1]) / 2))
    return fpr, tpr, auc


def tune_thresholds(score, y):
    """Choose the two class borders from VALIDATION data only.
    t_normal   : risk above which traffic is 'Suspicious' -> maximises (recall + specificity) / 2
    t_malicious: lowest risk above which at least 97 % of the flagged records are real attacks."""
    y = np.asarray(y).astype(bool)
    best_t, best = 50.0, -1
    for t in np.arange(1, 100, 1.0):
        p = score >= t
        bal = ((p & y).sum() / max(y.sum(), 1) + (~p & ~y).sum() / max((~y).sum(), 1)) / 2
        if bal > best:
            best, best_t = bal, t
    t_mal = None
    for t in np.arange(best_t + 5, 100, 1.0):
        p = score >= t
        if p.sum() >= 50 and y[p].mean() >= 0.97:
            t_mal = t
            break
    if t_mal is None:
        t_mal = best_t + (100 - best_t) / 2
    return float(best_t), float(t_mal)


def rules_to_text(rule):
    return (" " + rule["op"] + " ").join(f"{VARIABLES[v]['label']} is {s.upper()}" for v, s in rule["cond"])


def check_rules(rules):
    """Detect duplicate or contradictory rules (same IF part)."""
    msgs, seen = [], {}
    for r in rules:
        key = (r["op"], tuple(sorted(map(tuple, r["cond"]))))
        if key in seen:
            other = seen[key]
            if other["mam"] != r["mam"]:
                msgs.append(f"Contradiction: {other['id']} and {r['id']} have the same IF part but different outputs.")
            else:
                msgs.append(f"Redundant: {other['id']} and {r['id']} have the same IF part and output.")
        seen[key] = r
    return msgs


# ---- configuration (membership functions + rules) is kept in session_state and ------------------
# ---- turned into JSON text, which is used as the cache key for the heavy calculations. ----------
def config_json(mfs, rules):
    slim = [{k: r[k] for k in ("id", "cond", "op", "mam", "sug", "weight", "enabled", "why")} for r in rules]
    return json.dumps({"mfs": mfs, "rules": slim}, sort_keys=True)


def config_from_json(text):
    d = json.loads(text)
    mfs = {v: {s: (k, p) for s, (k, p) in sets.items()} for v, sets in d["mfs"].items()}
    return mfs, d["rules"]


@st.cache_data(show_spinner=False)
def get_data():
    train, test = load_dataset(TRAIN_PATH), load_dataset(TEST_PATH)
    return train, test, fit_medians(train)


@st.cache_data(show_spinner="Running both fuzzy systems on the dataset ...")
def evaluate_config(cfg_text):
    """Heavy part, cached. Tunes thresholds on the validation split and scores the test file."""
    mfs, rules = config_from_json(cfg_text)
    train, test, med = get_data()
    fit, val = split_train(train)
    v_res, _, _, _, _ = run_models(val, med, mfs, rules)
    y_val = (val["actual"] == "Attack").values
    thr = {m: tune_thresholds(v_res[m + "_risk"].values, y_val) for m in ("mamdani", "sugeno")}
    t_res, m_fire, s_fire, rep, _ = run_models(test, med, mfs, rules)
    # timing: median of 3 runs on 5000 test records
    sample = test.sample(5000, random_state=1)
    xn, _ = preprocess(sample, med)
    times = {"Mamdani": [], "Sugeno": []}
    for _ in range(3):
        a = time.perf_counter(); mamdani_infer(xn, mfs, rules)
        b = time.perf_counter(); sugeno_infer(xn, mfs, rules)
        c = time.perf_counter()
        times["Mamdani"].append(b - a); times["Sugeno"].append(c - b)
    ms_per_1000 = {k: float(np.median(v)) / len(sample) * 1000 * 1000 for k, v in times.items()}
    return dict(thr=thr, test=t_res, m_fire=m_fire, s_fire=s_fire, ms_per_1000=ms_per_1000,
                val_auc={m: roc_curve(y_val, v_res[m + "_risk"].values)[2] for m in ("mamdani", "sugeno")})


@st.cache_data(show_spinner="Analysing rules on the training split ...")
def rule_analysis(cfg_text):
    """For every rule: how often does it fire on the FIT part of the training data and how many of
    those records are real attacks? Used to refine rules without touching the test file."""
    mfs, rules = config_from_json(cfg_text)
    train, _, med = get_data()
    fit, _ = split_train(train)
    xn, _ = preprocess(fit, med)
    _, fire = mamdani_infer(xn, mfs, rules)
    y = (fit["actual"] == "Attack").values
    rows = []
    for i, r in enumerate(rules):
        act = fire[:, i] > 0.5 * max(r["weight"], 0.05)
        share = float(y[act].mean()) if act.sum() else np.nan
        if act.sum() == 0:
            verdict = "never fires"
        elif r["mam"] == "Low" and share > 0.20:
            verdict = "review: too many attacks"
        elif r["mam"] == "High" and share < 0.70:
            verdict = "review: too many normals"
        else:
            verdict = "consistent"
        rows.append(dict(rule=r["id"], records_fired=int(act.sum()), attack_share=share,
                         expected=r["mam"], verdict=verdict))
    return pd.DataFrame(rows)


def get_thresholds(model, tuned):
    if st.session_state.get("use_tuned", True):
        return tuned[model]
    return st.session_state["thr_" + model]


def alerts_from_class(cls):
    """Binary decision used for the evaluation: Suspicious counts as an alert (default)."""
    cls = np.asarray(cls)
    return (cls != "Normal") if st.session_state.get("susp_alert", True) else (cls == "Malicious")


def full_metrics(actual, risk, thr):
    y = (np.asarray(actual) == "Attack")
    cls = classify(risk, *thr)
    c = confusion(y, alerts_from_class(cls))
    m = metrics_from(c)
    fpr, tpr, auc = roc_curve(y, risk)
    return dict(m=m, c=c, fpr=fpr, tpr=tpr, auc=auc, cls=cls)


def verdict_text(M):
    """Plain-English comparison generated from the measured numbers (never hard-coded results)."""
    a, b = M["Mamdani"], M["Sugeno"]
    pick = lambda key, hi=True: "Mamdani" if ((a[key] > b[key]) == hi) else "Sugeno"
    lines = [
        f"**Overall (F1-score):** {pick('F1')} is better "
        f"(Mamdani {a['F1']:.3f} vs Sugeno {b['F1']:.3f}). "
        f"Accuracy: Mamdani {a['Accuracy']:.3f} vs Sugeno {b['Accuracy']:.3f}.",
        f"**Attack detection (recall):** {pick('Recall')} detects more attacks "
        f"(Mamdani {a['Recall']:.3f} vs Sugeno {b['Recall']:.3f}).",
        f"**False positives:** {pick('FPR', hi=False)} raises fewer false alarms "
        f"(FPR Mamdani {a['FPR']:.3f} vs Sugeno {b['FPR']:.3f}).",
        f"**Ranking quality (AUC):** {pick('AUC')} separates normal and attack scores better "
        f"(Mamdani {a['AUC']:.3f} vs Sugeno {b['AUC']:.3f}).",
        f"**Speed:** {pick('ms', hi=False)} is faster "
        f"(Mamdani {a['ms']:.1f} ms vs Sugeno {b['ms']:.1f} ms per 1000 records).",
    ]
    return lines


# =============================================================================
# 8. PLOTTING HELPERS (neon dark theme)
# =============================================================================
def style(fig, title, height=380, xtitle=None, ytitle=None):
    fig.update_layout(
        template="plotly_dark", title=dict(text=title, font=dict(size=16, color="#e6f7ff")),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(10,18,40,0.35)", height=height,
        margin=dict(l=50, r=20, t=55, b=45), font=dict(color="#cfe9ff"),
        legend=dict(bgcolor="rgba(0,0,0,0)", orientation="h", y=-0.2),
    )
    fig.update_xaxes(gridcolor="rgba(120,160,255,0.12)", title=xtitle)
    fig.update_yaxes(gridcolor="rgba(120,160,255,0.12)", title=ytitle)
    return fig


def show(fig):
    st.plotly_chart(fig, width="stretch")


def gauge(value, title, t_normal, t_mal):
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=float(value), title={"text": title, "font": {"size": 16}},
        number={"suffix": " /100", "font": {"color": "#e6f7ff"}},
        gauge={"axis": {"range": [0, 100]}, "bar": {"color": CYAN},
               "bgcolor": "rgba(0,0,0,0)",
               "steps": [{"range": [0, t_normal], "color": "rgba(34,255,170,0.35)"},
                         {"range": [t_normal, t_mal], "color": "rgba(255,176,32,0.35)"},
                         {"range": [t_mal, 100], "color": "rgba(255,59,107,0.40)"}]}))
    fig.update_layout(height=250, paper_bgcolor="rgba(0,0,0,0)", font=dict(color="#cfe9ff"),
                      margin=dict(l=25, r=25, t=60, b=10))
    return fig


def confusion_figure(c, title):
    z = [[c["TN"], c["FP"]], [c["FN"], c["TP"]]]
    fig = go.Figure(go.Heatmap(z=z, x=["Predicted Normal", "Predicted Attack"], y=["Actual Normal", "Actual Attack"],
                               colorscale=[[0, "#0b1230"], [1, CYAN]], showscale=False,
                               text=[[f"{v:,}" for v in row] for row in z], texttemplate="%{text}",
                               textfont=dict(size=20, color="white")))
    fig.update_yaxes(autorange="reversed")
    return style(fig, title, 330)


def membership_figure(var, mfs, marker=None):
    cfg = VARIABLES[var]
    xs = np.linspace(0, 1, 400)
    xr = xs * (np.log10(1 + cfg["cap"]) if cfg["log"] else cfg["cap"])
    fig = go.Figure()
    for (name, (k, p)), col in zip(mfs[var].items(), [CYAN, PURPLE, AMBER, GREEN]):
        fig.add_trace(go.Scatter(x=xr, y=membership(k, p, xs), name=f"{name} ({k})", mode="lines",
                                 line=dict(color=col, width=3), fill="tozeroy"))
    if marker is not None:
        fig.add_vline(x=marker, line_dash="dash", line_color="#ffffff")
    unit = "log10(1 + bytes)" if cfg["log"] else "raw value"
    return style(fig, f"Membership functions: {cfg['label']}", 330, xtitle=f"{cfg['label']} ({unit})",
                 ytitle="Membership degree")


def output_figure():
    fig = go.Figure()
    for (name, (k, p)), col in zip(OUT_MF.items(), [GREEN, AMBER, RED]):
        fig.add_trace(go.Scatter(x=UNIVERSE, y=membership(k, p, UNIVERSE), name=f"{name} ({k})",
                                 line=dict(color=col, width=3), fill="tozeroy"))
    return style(fig, "Mamdani output sets (risk score)", 330, xtitle="Risk score", ytitle="Membership degree")


# =============================================================================
# 9. INPUT HANDLING FOR UPLOADED FILES / MANUAL ENTRY
# =============================================================================
def read_uploaded_csv(file):
    """Read a CSV; accept files with a header row or raw NSL-KDD files without header."""
    try:
        df = pd.read_csv(file)
    except Exception as exc:
        return None, f"Could not read the file: {exc}"
    if df.empty:
        return None, "The uploaded file is empty."
    if not any(c in df.columns for c in COLUMNS):            # probably no header row
        file.seek(0)
        raw = pd.read_csv(file, header=None)
        if raw.shape[1] in (41, 42, 43):
            raw.columns = COLUMNS[:raw.shape[1]]
            df = raw
        else:
            return None, "No known NSL-KDD column names found and the column count is not 41-43."
    return df, None


def add_labels(df):
    """If the data contains a 'label' column, derive actual class and family."""
    df = df.copy()
    if "label" in df.columns:
        names = df["label"].astype(str).str.strip().str.lower().str.rstrip(".")
        df["actual"] = np.where(names == "normal", "Normal", "Attack")
        df["family"] = names.map(lambda n: "Normal" if n == "normal" else FAMILY.get(n, "Other"))
    return df


def score_records(df, source, tuned):
    """Score raw records with both models and return a tidy frame ready for the history table."""
    _, _, med = get_data()
    mfs, rules = st.session_state["mfs"], st.session_state["rules"]
    res, m_fire, s_fire, rep, _ = run_models(df, med, mfs, rules)
    tm, ts = get_thresholds("mamdani", tuned), get_thresholds("sugeno", tuned)
    out = pd.DataFrame(index=df.index)
    out["source"] = source
    out["actual"] = df["actual"].values if "actual" in df.columns else "unknown"
    out["family"] = df["family"].values if "family" in df.columns else "unknown"
    out["mamdani_risk"] = res["mamdani_risk"].round(2)
    out["sugeno_risk"] = res["sugeno_risk"].round(2)
    out["mamdani_class"] = classify(res["mamdani_risk"].values, *tm)
    out["sugeno_class"] = classify(res["sugeno_risk"].values, *ts)
    out["agree"] = out["mamdani_class"] == out["sugeno_class"]
    for v in VARIABLES:
        out[v] = df[v].values if v in df.columns else np.nan
    return out.reset_index(drop=True), m_fire, s_fire, rep


def append_history(frame):
    h = st.session_state["history"]
    frame = frame.copy()
    frame["batch"] = st.session_state["batch_no"] = st.session_state.get("batch_no", 0) + 1
    frame["time"] = pd.Timestamp.now().strftime("%H:%M:%S")
    start = st.session_state.get("event_no", 0)
    frame["event"] = np.arange(start + 1, start + len(frame) + 1)
    st.session_state["event_no"] = start + len(frame)
    h = pd.concat([h, frame], ignore_index=True) if len(h) else frame
    st.session_state["history"] = h.tail(5000).reset_index(drop=True)


# =============================================================================
# 10. STREAMLIT USER INTERFACE
# =============================================================================
CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
html, body, [class*="css"] { font-family: 'Inter', 'Segoe UI', Roboto, sans-serif; }
.stApp { background: radial-gradient(circle at 12% 8%, rgba(59,130,246,0.18), transparent 38%),
                     radial-gradient(circle at 90% 15%, rgba(168,85,247,0.18), transparent 40%),
                     linear-gradient(160deg, #02040c 0%, #070d22 55%, #0a1030 100%); color: #dff3ff; }
.block-container { max-width: 1500px; padding-top: 1.6rem; padding-bottom: 3rem; }
header[data-testid="stHeader"] { background: transparent; }
section[data-testid="stSidebar"] { background: linear-gradient(180deg, rgba(5,10,28,0.97), rgba(10,14,40,0.97));
        border-right: 1px solid rgba(0,245,255,0.25); box-shadow: 0 0 30px rgba(0,245,255,0.08); }
h1, h2, h3 { color: #eaf8ff; letter-spacing: 0.3px; }
.hero { padding: 22px 28px; border-radius: 20px; margin-bottom: 18px;
        background: linear-gradient(120deg, rgba(0,245,255,0.10), rgba(168,85,247,0.14));
        border: 1px solid rgba(0,245,255,0.35); box-shadow: 0 0 28px rgba(0,245,255,0.15);
        backdrop-filter: blur(14px); }
.hero h1 { margin: 0; font-size: 2rem; font-weight: 800;
        background: linear-gradient(90deg, #00f5ff, #3b82f6, #a855f7); -webkit-background-clip: text;
        -webkit-text-fill-color: transparent; }
.hero p { margin: 6px 0 0 0; color: #a9c7e8; }
.glass { background: rgba(255,255,255,0.045); border: 1px solid rgba(120,200,255,0.25); border-radius: 16px;
         padding: 16px 20px; margin: 8px 0 14px 0; backdrop-filter: blur(12px);
         box-shadow: 0 6px 24px rgba(0,0,0,0.45), inset 0 0 18px rgba(0,245,255,0.04); }
.glass b { color: #00f5ff; }
.sim { border-left: 4px solid #ffb020; }
.bad { border-left: 4px solid #ff3b6b; }
.good { border-left: 4px solid #22ffaa; }
div[data-testid="stMetric"] { background: rgba(255,255,255,0.05); border: 1px solid rgba(0,245,255,0.3);
        border-radius: 14px; padding: 12px 16px; box-shadow: 0 0 16px rgba(0,245,255,0.10); }
div[data-testid="stMetricValue"] { color: #00f5ff; }
div[data-testid="stMetricValue"] > div { font-size: 1.6rem; overflow: visible; text-overflow: clip; white-space: nowrap; }
div[data-testid="stMetricLabel"] p { font-size: 0.8rem; white-space: normal; }
div[data-testid="stPlotlyChart"] { background: rgba(255,255,255,0.03); border: 1px solid rgba(120,160,255,0.22);
        border-radius: 16px; padding: 6px; box-shadow: 0 4px 20px rgba(0,0,0,0.4); }
.stButton > button, .stDownloadButton > button { background: linear-gradient(90deg, #0891b2, #3b82f6, #7c3aed);
        color: white; border: 1px solid rgba(0,245,255,0.5); border-radius: 12px; font-weight: 600;
        box-shadow: 0 0 14px rgba(0,245,255,0.3); }
.stButton > button:hover { box-shadow: 0 0 24px rgba(0,245,255,0.7); border-color: #00f5ff; }
button[data-baseweb="tab"] { color: #9fc4e8; }
button[data-baseweb="tab"][aria-selected="true"] { color: #00f5ff; }
div[data-testid="stExpander"] { background: rgba(255,255,255,0.035); border: 1px solid rgba(120,200,255,0.2);
        border-radius: 14px; }
.tag { display:inline-block; padding:2px 10px; border-radius:999px; font-size:0.8rem; margin-right:6px;
       border:1px solid rgba(0,245,255,0.5); color:#00f5ff; }
</style>
"""


def hero(title, subtitle):
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def card(html, kind=""):
    st.markdown(f'<div class="glass {kind}">{html}</div>', unsafe_allow_html=True)


def init_state():
    if "mfs" not in st.session_state:
        st.session_state["mfs"] = copy.deepcopy(DEFAULT_MF)
        st.session_state["rules"] = copy.deepcopy(DEFAULT_RULES)
        st.session_state["history"] = pd.DataFrame()


# -----------------------------------------------------------------------------
# Page 1: dataset overview
# -----------------------------------------------------------------------------
def page_overview(ev):
    train, test, med = get_data()
    hero("Dataset Inspection & Preprocessing", "What the NSL-KDD files contain and which features the fuzzy systems use")
    num, cat = split_feature_types(train)
    qt, qe = data_quality(train), data_quality(test)
    c = st.columns(5)
    c[0].metric("Training records", f"{qt['rows']:,}")
    c[1].metric("Test records", f"{qe['rows']:,}")
    c[2].metric("Numerical features", len(num))
    c[3].metric("Categorical features", len(cat))
    c[4].metric("Features used by fuzzy rules", len(VARIABLES))
    q = pd.DataFrame({"Training file": qt, "Test file": qe}).T
    q.columns = ["Rows", "Missing values", "Duplicate rows", "Negative values"]
    st.markdown("##### Data quality check")
    st.dataframe(q, width="stretch")
    unseen = sorted(set(test["attack_name"]) - set(train["attack_name"]))
    card(f"<b>Categorical features detected:</b> {', '.join(cat)}.<br>"
         f"<b>Label:</b> the column <i>label</i> holds the traffic type; it is only used to evaluate the system. "
         f"<i>difficulty</i> is a dataset helper column and is ignored.<br>"
         f"<b>Important:</b> the test file contains <b>{len(unseen)} attack types that never appear in the training file</b> "
         f"({', '.join(unseen[:8])}, ...). The test score therefore measures how well the fuzzy rules generalise.")

    left, right = st.columns(2)
    dist = pd.DataFrame({"Training": train["actual"].value_counts(), "Test": test["actual"].value_counts()}).reset_index()
    dist.columns = ["Class", "Training", "Test"]
    dist = dist.melt("Class", var_name="File", value_name="Records")
    fig = px.bar(dist, x="Class", y="Records", color="File", barmode="group",
                 color_discrete_map={"Training": CYAN, "Test": PURPLE}, text_auto=True)
    with left:
        show(style(fig, "Normal vs attack traffic", xtitle="Traffic class", ytitle="Number of records"))
    fam = pd.DataFrame({"Training": train["family"].value_counts(), "Test": test["family"].value_counts()}).fillna(0).reset_index()
    fam.columns = ["Family", "Training", "Test"]
    fam = fam.melt("Family", var_name="File", value_name="Records")
    fig = px.bar(fam, x="Family", y="Records", color="File", barmode="group",
                 color_discrete_map={"Training": CYAN, "Test": PURPLE}, text_auto=True)
    with right:
        show(style(fig, "Attack category distribution", xtitle="Attack family", ytitle="Number of records"))

    rel = feature_relevance(train)
    fig = px.bar(rel.head(20).iloc[::-1], x="relevance", y="feature", orientation="h", color="used_in_fuzzy_model",
                 color_discrete_map={True: CYAN, False: "#4b5a8a"}, hover_data={"auc": ":.3f"})
    show(style(fig, "Feature relevance (training data, single-feature AUC)", 560,
               xtitle="Relevance = |AUC - 0.5| x 2  (0 = useless, 1 = perfect)", ytitle="Feature"))
    card("<b>How features were chosen:</b> every numeric feature was ranked by how well it alone separates normal from attack "
         "traffic. For each group of near-identical features (e.g. <i>serror_rate</i>, <i>srv_serror_rate</i>, "
         "<i>dst_host_serror_rate</i>) only one strong representative was kept so rules stay readable. "
         "Note that <i>num_failed_logins</i> (used in the sample project) has relevance 0.0 in this dataset, so it was dropped.")

    st.markdown("##### Features used by the fuzzy systems")
    t = pd.DataFrame([dict(feature=k, meaning=v["info"], scaling=("log10(1+x) / log10(1+%g)" % v["cap"]) if v["log"]
                           else f"x / {v['cap']:g} (clipped at {v['cap']:g})", train_median=med[k])
                      for k, v in VARIABLES.items()])
    st.dataframe(t, width="stretch", hide_index=True)
    card("<b>Preprocessing (identical for Mamdani and Sugeno):</b> (1) convert to numbers; (2) missing / infinite values "
         "are replaced by the training median; (3) negative values are set to 0; (4) outliers are clipped at the cap shown "
         "above; (5) every feature is scaled to 0..1 (byte counts use a log scale because they are extremely skewed). "
         "The original data had no missing values or duplicates, so steps 2-4 mainly protect manual and uploaded input.")


# -----------------------------------------------------------------------------
# Page 2: membership functions and rules
# -----------------------------------------------------------------------------
def mf_table(mfs):
    rows = []
    for v, sets in mfs.items():
        for s, (k, p) in sets.items():
            q = list(p) + [np.nan] * (4 - len(p))
            rows.append(dict(variable=v, fuzzy_set=s, type=k, p1=q[0], p2=q[1], p3=q[2], p4=q[3]))
    return pd.DataFrame(rows)


def parse_mf_table(df):
    """Validate the edited table; return (new_mfs, error_message)."""
    new = {}
    for _, r in df.iterrows():
        k = r["type"]
        n = {"tri": 3, "trap": 4, "gauss": 2}[k]
        p = [r["p1"], r["p2"], r["p3"], r["p4"]][:n]
        if any(pd.isna(x) for x in p):
            return None, f"{r['variable']}/{r['fuzzy_set']}: a parameter is empty."
        p = [float(x) for x in p]
        if k == "gauss" and p[1] <= 0:
            return None, f"{r['variable']}/{r['fuzzy_set']}: sigma must be > 0."
        if k != "gauss" and p != sorted(p):
            return None, f"{r['variable']}/{r['fuzzy_set']}: parameters must be in increasing order."
        new.setdefault(r["variable"], {})[r["fuzzy_set"]] = (k, p)
    return new, None


def page_rules(ev):
    hero("Fuzzy Membership Functions & Rule Base", "Inspect, analyse and adjust the knowledge of both fuzzy systems")
    mfs, rules = st.session_state["mfs"], st.session_state["rules"]
    t_mf, t_rules, t_an, t_edit = st.tabs(["Membership functions", "Rule base", "Rule analysis", "Adjust & save"])

    with t_mf:
        card("Every input is scaled to 0..1 first. The curves below are drawn in the original units. "
             "<b>Triangular</b> sets describe 'medium' values, <b>trapezoidal</b> sets describe the shoulders (low / high) "
             "and a <b>Gaussian</b> set is used for 'medium' connection counts. Overlapping sets mean a value can belong "
             "to two sets at once (e.g. 0.4 SYN-error rate is partly LOW and partly MEDIUM).")
        names = list(VARIABLES)
        cols = st.columns(2)
        for i, v in enumerate(names):
            with cols[i % 2]:
                show(membership_figure(v, mfs))
        show(output_figure())

    with t_rules:
        card("Both systems share the same <b>IF-part</b> (what traffic looks like) but each has its own <b>THEN-part</b>: "
             "Mamdani uses fuzzy output sets (Low / Medium / High) while Sugeno uses a crisp constant risk value.")
        table = pd.DataFrame([dict(ID=r["id"], IF=rules_to_text(r), Mamdani_THEN=r["mam"] + " risk",
                                   Sugeno_THEN=r["sug"], Weight=r["weight"], Enabled=r["enabled"], Purpose=r["why"])
                              for r in rules])
        st.dataframe(table, width="stretch", hide_index=True, height=640)
        for msg in check_rules(rules):
            st.warning(msg)
        if not check_rules(rules):
            st.success("Rule check: no contradictory or redundant rules found.")

    with t_an:
        card("<b>Rule refinement without data leakage.</b> The rules were studied on 70 % of the <i>training</i> file only. "
             "For each rule we count the records where it fires strongly (> 0.5) and how many of them are real attacks. "
             "A rule that says LOW risk should have a small attack share, a rule that says HIGH risk a large one. "
             "The test file was never used for this.")
        ra = rule_analysis(config_json(mfs, rules))
        fig = px.bar(ra, x="rule", y="attack_share", color="expected", text_auto=".2f",
                     color_discrete_map={"Low": GREEN, "Medium": AMBER, "High": RED},
                     category_orders={"expected": ["Low", "Medium", "High"]})
        show(style(fig, "Share of real attacks among records where each rule fires (training split)",
                   xtitle="Rule", ytitle="Attack share (0 = all normal, 1 = all attacks)"))
        st.dataframe(ra, width="stretch", hide_index=True)

    with t_edit:
        st.markdown("##### Rule editor")
        st.caption("Change the enabled flag, weight (0-1.5), Mamdani output set or Sugeno constant, then press Apply.")
        base = pd.DataFrame([dict(id=r["id"], rule=rules_to_text(r), enabled=r["enabled"], weight=r["weight"],
                                  mamdani_output=r["mam"], sugeno_constant=r["sug"]) for r in rules])
        edited = st.data_editor(base, hide_index=True, width="stretch", key="rule_editor",
                                disabled=["id", "rule"],
                                column_config={"mamdani_output": st.column_config.SelectboxColumn(options=["Low", "Medium", "High"]),
                                               "weight": st.column_config.NumberColumn(min_value=0.0, max_value=1.5, step=0.05),
                                               "sugeno_constant": st.column_config.NumberColumn(min_value=0.0, max_value=100.0)})
        if st.button("Apply rule changes"):
            for r, (_, e) in zip(rules, edited.iterrows()):
                r["enabled"], r["weight"] = bool(e["enabled"]), float(np.clip(e["weight"], 0, 1.5))
                r["mam"], r["sug"] = e["mamdani_output"], float(np.clip(e["sugeno_constant"], 0, 100))
            st.rerun()

        with st.expander("Add a new rule"):
            c = st.columns(3)
            conds = []
            for i in range(3):
                v = c[i].selectbox(f"Condition {i + 1} feature", ["(none)"] + list(VARIABLES), key=f"nv{i}")
                s = c[i].selectbox(f"Condition {i + 1} fuzzy set", list(mfs[v]) if v != "(none)" else ["-"], key=f"ns{i}")
                if v != "(none)":
                    conds.append((v, s))
            d = st.columns(3)
            op = d[0].selectbox("Operator", ["AND", "OR"])
            mam = d[1].selectbox("Mamdani output", ["Low", "Medium", "High"], index=1)
            sug = d[2].number_input("Sugeno constant (0-100)", 0.0, 100.0, 50.0)
            if st.button("Add rule"):
                if not conds:
                    st.error("Choose at least one condition.")
                else:
                    rid = f"U{sum(1 for r in rules if r['id'].startswith('U')) + 1}"
                    rules.append(R(rid, conds, mam, sug, "User-defined rule.", op=op))
                    st.rerun()

        with st.expander("Edit membership function parameters (normalised 0-1 scale)"):
            st.caption("tri = [a, b, c]   trap = [a, b, c, d]   gauss = [mean, sigma]. Parameters must be increasing.")
            ed = st.data_editor(mf_table(mfs), hide_index=True, width="stretch", key="mf_editor",
                                disabled=["variable", "fuzzy_set"],
                                column_config={"type": st.column_config.SelectboxColumn(options=["tri", "trap", "gauss"])})
            if st.button("Apply membership changes"):
                new, err = parse_mf_table(ed)
                if err:
                    st.error(err)
                else:
                    st.session_state["mfs"] = new
                    st.rerun()

        c1, c2, c3 = st.columns(3)
        if c1.button("Reset to default rules and membership functions"):
            st.session_state["mfs"] = copy.deepcopy(DEFAULT_MF)
            st.session_state["rules"] = copy.deepcopy(DEFAULT_RULES)
            st.rerun()
        if c2.button("Save configuration to saved_config/"):
            os.makedirs(os.path.join(BASE, "saved_config"), exist_ok=True)
            with open(os.path.join(BASE, "saved_config", "fuzzy_config.json"), "w") as f:
                f.write(config_json(mfs, rules))
            st.success("Saved to saved_config/fuzzy_config.json")
        if c3.button("Load saved configuration"):
            path = os.path.join(BASE, "saved_config", "fuzzy_config.json")
            if os.path.exists(path):
                m, rl = config_from_json(open(path).read())
                for r in rl:
                    r["cond"] = [tuple(x) for x in r["cond"]]
                st.session_state["mfs"], st.session_state["rules"] = m, rl
                st.rerun()
            else:
                st.error("No saved configuration found.")


# -----------------------------------------------------------------------------
# Page 3: Mamdani vs Sugeno comparison
# -----------------------------------------------------------------------------
def compute_models(ev):
    """Metrics for both models on the TEST file, with the current thresholds."""
    train, test, med = get_data()
    out = {}
    for name, key in (("Mamdani", "mamdani"), ("Sugeno", "sugeno")):
        thr = get_thresholds(key, ev["thr"])
        r = full_metrics(test["actual"].values, ev["test"][key + "_risk"].values, thr)
        r["thr"] = thr
        out[name] = r
    return out


def page_compare(ev):
    hero("Mamdani vs Sugeno Comparison", "Both fuzzy systems evaluated on the official test file with the real dataset labels")
    train, test, med = get_data()
    R_ = compute_models(ev)
    M = {n: dict(r["m"], AUC=r["auc"], ms=ev["ms_per_1000"][n]) for n, r in R_.items()}

    cols = st.columns(2)
    for col, n in zip(cols, ("Mamdani", "Sugeno")):
        with col:
            st.markdown(f"##### {n}")
            a = st.columns(4)
            a[0].metric("Accuracy", f"{M[n]['Accuracy']:.3f}")
            a[1].metric("Recall", f"{M[n]['Recall']:.3f}")
            a[2].metric("False-pos. rate", f"{M[n]['FPR']:.3f}")
            a[3].metric("AUC", f"{M[n]['AUC']:.3f}")

    tab = pd.DataFrame({n: {"Accuracy": M[n]["Accuracy"], "Precision": M[n]["Precision"], "Recall": M[n]["Recall"],
                            "F1-score": M[n]["F1"], "Specificity": M[n]["Specificity"],
                            "False Positive Rate": M[n]["FPR"], "False Negative Rate": M[n]["FNR"],
                            "AUC": M[n]["AUC"], "Time (ms per 1000 rec.)": M[n]["ms"]} for n in M})
    st.dataframe(tab.style.format("{:.4f}"), width="stretch")

    keys = ["Accuracy", "Precision", "Recall", "F1", "Specificity", "FPR", "FNR", "AUC"]
    long = pd.DataFrame([dict(Metric=k, Model=n, Value=M[n][k]) for n in M for k in keys])
    fig = px.bar(long, x="Metric", y="Value", color="Model", barmode="group", text_auto=".3f",
                 color_discrete_map={"Mamdani": CYAN, "Sugeno": PURPLE})
    show(style(fig, "Mamdani vs Sugeno: evaluation metrics (test file)", 420, xtitle="Metric", ytitle="Value (0-1)"))

    c1, c2 = st.columns(2)
    with c1:
        show(confusion_figure(R_["Mamdani"]["c"], "Confusion matrix: Mamdani"))
    with c2:
        show(confusion_figure(R_["Sugeno"]["c"], "Confusion matrix: Sugeno"))

    d1, d2 = st.columns(2)
    fig = go.Figure()
    for n, col in (("Mamdani", CYAN), ("Sugeno", PURPLE)):
        fig.add_trace(go.Scatter(x=R_[n]["fpr"], y=R_[n]["tpr"], mode="lines", line=dict(color=col, width=3),
                                 name=f"{n} (AUC = {R_[n]['auc']:.3f})"))
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", line=dict(color="#667", dash="dash"), name="Random guess"))
    with d1:
        show(style(fig, "ROC curves", 400, xtitle="False positive rate", ytitle="True positive rate (recall)"))
    fig = px.bar(x=list(M), y=[M[n]["ms"] for n in M], color=list(M), text_auto=".1f",
                 color_discrete_map={"Mamdani": CYAN, "Sugeno": PURPLE})
    fig.update_layout(showlegend=False)
    with d2:
        show(style(fig, "Prediction time (measured on 5,000 test records)", 400, xtitle="Model",
                   ytitle="Milliseconds per 1000 records"))

    st.markdown("### Which model is better?")
    card("<br>".join(verdict_text(M)), "good")
    card("<b>Differences between the two inference methods</b><br>"
         "&bull; <b>Mamdani:</b> rule outputs are fuzzy sets (Low / Medium / High). AND = <i>min</i>, OR = <i>max</i>; "
         "each output set is clipped by the rule strength (min implication), clipped sets are combined with <i>max</i> "
         "and the risk is the <i>centroid</i> of the combined shape. Intuitive and smooth, but slower and the score "
         "can never reach exactly 0 or 100.<br>"
         "&bull; <b>Sugeno (zero-order):</b> rule outputs are constants. AND = <i>product</i>, OR = probabilistic sum and "
         "the risk is the <i>weighted average</i> of the constants. No output sets and no centroid, so it is faster, "
         "uses the full 0-100 range and each rule's influence is easy to tune."
         f"<br>&bull; Thresholds (borders Normal | Suspicious | Malicious) - Mamdani: {R_['Mamdani']['thr'][0]:.0f} / "
         f"{R_['Mamdani']['thr'][1]:.0f}, Sugeno: {R_['Sugeno']['thr'][0]:.0f} / {R_['Sugeno']['thr'][1]:.0f}. "
         "They were tuned on a validation split of the training file, never on the test file.")
    if st.session_state.get("susp_alert", True):
        st.caption("Binary evaluation: Suspicious and Malicious both count as an alert (change this in the sidebar).")
    else:
        st.caption("Binary evaluation: only Malicious counts as an alert (change this in the sidebar).")

    st.markdown("##### Detection rate per attack family (test file)")
    rows = []
    for n, r in R_.items():
        alert = alerts_from_class(r["cls"])
        for f_ in ["Normal", "DoS", "Probe", "R2L", "U2R"]:
            m = (test["family"] == f_).values
            if m.sum():
                rows.append(dict(Family=f_, Model=n, Alert_rate=float(alert[m].mean()), Records=int(m.sum())))
    fam = pd.DataFrame(rows)
    fig = px.bar(fam, x="Family", y="Alert_rate", color="Model", barmode="group", text_auto=".2f",
                 hover_data=["Records"], color_discrete_map={"Mamdani": CYAN, "Sugeno": PURPLE})
    show(style(fig, "Share of records flagged as alert, per true family", 400, xtitle="True traffic family",
               ytitle="Alert rate (Normal = false alarms, others = detection)"))


# -----------------------------------------------------------------------------
# Page 4: prediction (manual + CSV)
# -----------------------------------------------------------------------------
def explain_table(m_fire_row, s_fire_row, rules):
    rows = []
    for i, r in enumerate(rules):
        if m_fire_row[i] > 0.001 or s_fire_row[i] > 0.001:
            rows.append(dict(Rule=r["id"], IF=rules_to_text(r), Mamdani_strength=round(float(m_fire_row[i]), 3),
                             Mamdani_output=r["mam"], Sugeno_strength=round(float(s_fire_row[i]), 3),
                             Sugeno_output=r["sug"], Meaning=r["why"]))
    if not rows:
        return pd.DataFrame(columns=["Rule", "IF", "Mamdani_strength", "Mamdani_output", "Sugeno_strength",
                                     "Sugeno_output", "Meaning"])
    return pd.DataFrame(rows).sort_values("Mamdani_strength", ascending=False)


def load_example(family):
    """Callback of the example buttons: copy a real test record into the input widgets."""
    _, test, _ = get_data()
    row = test[test["family"] == family].sample(1, random_state=int(time.time()) % 1000).iloc[0]
    for c in st.session_state["num_cols"]:
        st.session_state[f"in_{c}"] = float(row[c]) if st.session_state["is_float"][c] else int(row[c])
    for c in st.session_state["cat_cols"]:
        st.session_state[f"in_{c}"] = row[c]


def page_predict(ev):
    hero("Intrusion Prediction", "Enter network traffic parameters or upload a CSV file; both fuzzy systems answer instantly")
    train, test, med = get_data()
    num, cat = split_feature_types(train)
    tuned = ev["thr"]
    tab_manual, tab_csv = st.tabs(["Manual input", "CSV batch prediction"])

    # ---------------- manual ----------------
    with tab_manual:
        stats = train[num].agg(["min", "max", "median"])
        is_float = {c: bool((train[c] % 1 != 0).any()) for c in num}
        st.session_state["num_cols"], st.session_state["cat_cols"], st.session_state["is_float"] = num, cat, is_float
        for c in num:
            if f"in_{c}" not in st.session_state:
                st.session_state[f"in_{c}"] = float(stats.loc["median", c]) if is_float[c] else int(stats.loc["median", c])
        for c in cat:
            if f"in_{c}" not in st.session_state:
                st.session_state[f"in_{c}"] = train[c].mode()[0]

        st.markdown("**Load a real example from the test file:**")
        b = st.columns(5)
        for col, fam in zip(b, ["Normal", "DoS", "Probe", "R2L", "U2R"]):
            col.button(fam, key=f"ex_{fam}", on_click=load_example, args=(fam,), width="stretch")

        used = [c for c in num if c in VARIABLES]
        others = [c for c in num if c not in VARIABLES]
        st.markdown('<span class="tag">Used by the fuzzy rules</span>', unsafe_allow_html=True)
        cols = st.columns(4)
        for i, c in enumerate(used):
            kw = dict(min_value=0.0 if is_float[c] else 0, step=0.01 if is_float[c] else 1, key=f"in_{c}",
                      help=VARIABLES[c]["info"])
            if is_float[c] and stats.loc["max", c] <= 1:
                kw["max_value"] = 1.0
            cols[i % 4].number_input(f"{c}", **kw)
        with st.expander(f"Other dataset features ({len(others)} numeric + {len(cat)} categorical): "
                         "shown for completeness, not used by the fuzzy rules", expanded=True):
            cols = st.columns(4)
            for i, c in enumerate(others):
                cols[i % 4].number_input(c, min_value=0.0 if is_float[c] else 0, step=0.01 if is_float[c] else 1,
                                         key=f"in_{c}")
            for i, c in enumerate(cat):
                opts = sorted(train[c].unique())
                cols[(len(others) + i) % 4].selectbox(c, opts, key=f"in_{c}")

        record = {c: st.session_state.get(f"in_{c}") for c in num + cat}
        df = pd.DataFrame([record])
        res, m_fire, s_fire, rep, _ = run_models(df, med, st.session_state["mfs"], st.session_state["rules"])
        scored, _, _, _ = score_records(df, "manual", tuned)
        tm, ts = get_thresholds("mamdani", tuned), get_thresholds("sugeno", tuned)
        mc, sc = scored.loc[0, "mamdani_class"], scored.loc[0, "sugeno_class"]

        st.markdown("### Result")
        g1, g2 = st.columns(2)
        with g1:
            show(gauge(res.loc[0, "mamdani_risk"], "Mamdani risk score", *tm))
            st.markdown(f"<h3 style='text-align:center;color:{CLASS_COLORS[mc]}'>Mamdani: {mc}</h3>", unsafe_allow_html=True)
        with g2:
            show(gauge(res.loc[0, "sugeno_risk"], "Sugeno risk score", *ts))
            st.markdown(f"<h3 style='text-align:center;color:{CLASS_COLORS[sc]}'>Sugeno: {sc}</h3>", unsafe_allow_html=True)
        if mc != sc:
            card(f"<b>Disagreement:</b> Mamdani says <b>{mc}</b> but Sugeno says <b>{sc}</b>. "
                 "Check the rule table below to see which rules pull in different directions.", "bad")
        else:
            card(f"<b>Both systems agree:</b> {mc}.", "good")
        if rep["clipped"] or rep["invalid_fixed"] or rep["missing_filled"]:
            st.info(f"Input handling: {rep['clipped']} value(s) clipped to the allowed range, "
                    f"{rep['invalid_fixed']} invalid value(s) set to 0, {rep['missing_filled']} missing value(s) filled with the training median.")

        xn, _ = preprocess(df, med)
        _, _, agg = mamdani_infer(xn, st.session_state["mfs"], st.session_state["rules"], return_agg=True)
        p1, p2 = st.columns(2)
        fig = go.Figure(go.Scatter(x=UNIVERSE, y=agg[0], fill="tozeroy", line=dict(color=CYAN, width=3), name="Aggregated output"))
        fig.add_vline(x=res.loc[0, "mamdani_risk"], line_dash="dash", line_color="#fff",
                      annotation_text=f"centroid = {res.loc[0, 'mamdani_risk']:.1f}")
        with p1:
            show(style(fig, "Mamdani: aggregated output set and centroid", 360, xtitle="Risk score", ytitle="Membership degree"))
        ex = explain_table(m_fire[0], s_fire[0], st.session_state["rules"])
        fig = go.Figure()
        fig.add_trace(go.Bar(x=ex["Rule"], y=ex["Mamdani_strength"], name="Mamdani strength (min/max)", marker_color=CYAN))
        fig.add_trace(go.Bar(x=ex["Rule"], y=ex["Sugeno_strength"], name="Sugeno strength (product)", marker_color=PURPLE))
        fig.update_layout(barmode="group")
        with p2:
            show(style(fig, "Fuzzy rules activated by this record", 360, xtitle="Rule", ytitle="Firing strength (0-1)"))
        st.markdown("##### Activated rules and their meaning")
        st.dataframe(ex, width="stretch", hide_index=True)

        mem = st.expander("Where does this record sit on the membership functions?")
        with mem:
            cols = st.columns(2)
            for i, v in enumerate(VARIABLES):
                val = float(pd.to_numeric(df.get(v), errors="coerce").fillna(med[v]).iloc[0]) if v in df else med[v]
                val = max(0.0, min(val, VARIABLES[v]["cap"]))
                mark = np.log10(1 + val) if VARIABLES[v]["log"] else val
                with cols[i % 2]:
                    show(membership_figure(v, st.session_state["mfs"], mark))
        if st.button("Submit this record to the Live Monitor"):
            append_history(scored)
            st.success("Record added to the Live Monitor.")

    # ---------------- CSV ----------------
    with tab_csv:
        card("Upload a CSV with NSL-KDD columns (with or without header). Missing columns are filled with training medians, "
             "invalid values are corrected and results can be downloaded. If a <i>label</i> column exists, accuracy is reported.")
        st.download_button("Download a sample CSV (50 test records)", test.head(50)[COLUMNS].to_csv(index=False),
                           "sample_traffic.csv", "text/csv")
        up = st.file_uploader("Upload CSV", type=["csv", "txt"])
        if up is not None:
            df, err = read_uploaded_csv(up)
            if err:
                st.error(err)
            else:
                known = [c for c in VARIABLES if c in df.columns]
                if not known:
                    st.error("None of the fuzzy-model features were found in the file.")
                else:
                    missing = [c for c in VARIABLES if c not in df.columns]
                    if missing:
                        st.warning("Missing columns filled with training medians: " + ", ".join(missing))
                    df = add_labels(df)
                    scored, m_fire, s_fire, rep = score_records(df, "csv", tuned)
                    st.success(f"{len(scored):,} records scored.  Fixed: {rep['missing_filled']} missing, "
                               f"{rep['invalid_fixed']} invalid, {rep['clipped']} clipped values.")
                    cnt = pd.DataFrame({"Mamdani": scored["mamdani_class"].value_counts(),
                                        "Sugeno": scored["sugeno_class"].value_counts()}).reindex(CLASSES).fillna(0).reset_index()
                    cnt.columns = ["Class", "Mamdani", "Sugeno"]
                    cnt = cnt.melt("Class", var_name="Model", value_name="Records")
                    fig = px.bar(cnt, x="Class", y="Records", color="Model", barmode="group", text_auto=True,
                                 color_discrete_map={"Mamdani": CYAN, "Sugeno": PURPLE})
                    a, b = st.columns(2)
                    with a:
                        show(style(fig, "Predicted classes in the uploaded file", 360, xtitle="Predicted class", ytitle="Records"))
                    dis = int((~scored["agree"]).sum())
                    with b:
                        fig = px.histogram(scored.melt(value_vars=["mamdani_risk", "sugeno_risk"], var_name="Model", value_name="Risk"),
                                           x="Risk", color="Model", barmode="overlay", nbins=40, opacity=0.65,
                                           color_discrete_map={"mamdani_risk": CYAN, "sugeno_risk": PURPLE})
                        show(style(fig, "Risk score distribution", 360, xtitle="Risk score", ytitle="Records"))
                    st.metric("Records where the two models disagree", f"{dis:,} ({dis / len(scored):.1%})")
                    if "actual" in df.columns:
                        mm = {}
                        for n, k in (("Mamdani", "mamdani_class"), ("Sugeno", "sugeno_class")):
                            cm = confusion(df["actual"].values == "Attack", alerts_from_class(scored[k].values))
                            mm[n] = metrics_from(cm)
                        st.markdown("##### Accuracy on the uploaded file (using its label column)")
                        st.dataframe(pd.DataFrame(mm).style.format("{:.4f}"), width="stretch")
                    st.markdown("##### Results (first 500 rows)")
                    show_cols = ["actual", "family", "mamdani_risk", "mamdani_class", "sugeno_risk", "sugeno_class", "agree"]
                    st.dataframe(scored[show_cols].head(500), width="stretch")
                    d1, d2 = st.columns(2)
                    d1.download_button("Download all predictions (CSV)", scored.to_csv(index=False), "predictions.csv", "text/csv")
                    if d2.button("Send these records to the Live Monitor"):
                        append_history(scored.head(2000))
                        st.success("Records added to the Live Monitor.")
        else:
            st.info("No file uploaded yet.")


# -----------------------------------------------------------------------------
# Page 5: live-style monitor (simulation / uploaded data)
# -----------------------------------------------------------------------------
def stream_batch(n, tuned):
    _, test, _ = get_data()
    batch = test.sample(n)
    scored, _, _, _ = score_records(batch, "simulation", tuned)
    append_history(scored)


def monitor_view(auto, n, tuned):
    if auto:
        stream_batch(n, tuned)
    h = st.session_state["history"]
    if h is None or len(h) == 0:
        st.info("No traffic yet. Press 'Stream next batch', switch on auto-stream, or send records from the Prediction page.")
        return
    tm, ts = get_thresholds("mamdani", tuned), get_thresholds("sugeno", tuned)
    st.caption("M / S = Mamdani / Sugeno counts")
    k = st.columns(5)
    k[0].metric("Events", f"{len(h):,}")
    for col, n_ in zip(k[1:4], CLASSES):
        col.metric(f"{n_}  (M / S)", f"{(h['mamdani_class'] == n_).sum()} / {(h['sugeno_class'] == n_).sum()}")
    k[4].metric("Model disagreements", f"{(~h['agree']).sum()}")

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=h["event"], y=h["mamdani_risk"], mode="lines+markers", name="Mamdani risk",
                             line=dict(color=CYAN)))
    fig.add_trace(go.Scatter(x=h["event"], y=h["sugeno_risk"], mode="lines+markers", name="Sugeno risk",
                             line=dict(color=PURPLE)))
    fig.add_hline(y=tm[1], line_dash="dot", line_color=RED, annotation_text="Mamdani malicious border")
    fig.add_hline(y=tm[0], line_dash="dot", line_color=AMBER, annotation_text="Mamdani suspicious border")
    show(style(fig, "Intrusion risk score of every event", 420, xtitle="Event number", ytitle="Risk score (0-100)"))

    a, b = st.columns(2)
    cnt = pd.DataFrame({"Mamdani": h["mamdani_class"].value_counts(), "Sugeno": h["sugeno_class"].value_counts()}) \
        .reindex(CLASSES).fillna(0).reset_index()
    cnt.columns = ["Class", "Mamdani", "Sugeno"]
    cnt = cnt.melt("Class", var_name="Model", value_name="Events")
    fig = px.bar(cnt, x="Class", y="Events", color="Model", barmode="group", text_auto=True,
                 color_discrete_map={"Mamdani": CYAN, "Sugeno": PURPLE})
    with a:
        show(style(fig, "Traffic classes: Mamdani vs Sugeno", 360, xtitle="Predicted class", ytitle="Events"))
    ag = h["agree"].map({True: "Models agree", False: "Models disagree"}).value_counts().reset_index()
    ag.columns = ["Result", "Events"]
    fig = px.pie(ag, names="Result", values="Events", hole=0.55, color="Result",
                 color_discrete_map={"Models agree": GREEN, "Models disagree": RED})
    with b:
        show(style(fig, "Agreement between the models", 360))

    c, d = st.columns(2)
    known = h[~h["family"].isin(["unknown"])]
    if len(known):
        fam = known["family"].value_counts().reset_index()
        fam.columns = ["Family", "Events"]
        fig = px.bar(fam, x="Family", y="Events", color="Family", text_auto=True,
                     color_discrete_sequence=[GREEN, RED, AMBER, PURPLE, BLUE, CYAN])
        fig.update_layout(showlegend=False)
        with c:
            show(style(fig, "Attack distribution (true family of events with known label)", 360,
                       xtitle="Traffic family", ytitle="Events"))
    else:
        c.info("Events have no label column, so the true attack distribution is unknown.")
    tr = h.groupby("batch").agg(Mamdani=("mamdani_class", lambda s: (s != "Normal").sum()),
                                Sugeno=("sugeno_class", lambda s: (s != "Normal").sum())).reset_index()
    fig = px.line(tr.melt("batch", var_name="Model", value_name="Alerts"), x="batch", y="Alerts", color="Model",
                  markers=True, color_discrete_map={"Mamdani": CYAN, "Sugeno": PURPLE})
    with d:
        show(style(fig, "Detection trend: alerts per batch", 360, xtitle="Batch number", ytitle="Alerts (Suspicious + Malicious)"))

    st.markdown("##### Prediction history (latest 100)")
    cols = ["event", "time", "source", "actual", "family", "mamdani_risk", "mamdani_class", "sugeno_risk", "sugeno_class", "agree"]
    st.dataframe(h[cols].tail(100).iloc[::-1], width="stretch", hide_index=True)


def page_monitor(ev):
    hero("Live-Style Intrusion Monitor", "Replay of test traffic, uploaded files and manual records scored by both fuzzy systems")
    card("<b>Simulation notice:</b> this application is <b>not connected to a real network</b>. The monitor replays random records "
         "from the NSL-KDD test file (or records you upload / enter manually) and scores them with the fuzzy systems. "
         "It does not capture or detect real network traffic.", "sim")
    tuned = ev["thr"]
    c = st.columns([1, 1, 1, 1])
    n = c[0].slider("Records per batch", 1, 50, 10)
    auto = c[1].toggle("Auto-stream every 2 s", value=False)
    if c[2].button("Stream next batch", width="stretch"):
        stream_batch(n, tuned)
    if c[3].button("Clear history", width="stretch"):
        st.session_state["history"] = pd.DataFrame()
        st.session_state["event_no"] = 0
        st.session_state["batch_no"] = 0
    runner = st.fragment(run_every=2)(monitor_view) if auto else st.fragment(monitor_view)
    runner(auto, n, tuned)


# -----------------------------------------------------------------------------
# Page 6: analytics gallery
# -----------------------------------------------------------------------------
def page_analytics(ev):
    hero("Interactive Analytics", "Score distributions, per-model performance, rule activation and trends")
    train, test, med = get_data()
    R_ = compute_models(ev)
    t1, t2, t3, t4, t5 = st.tabs(["Model performance", "Risk score distribution", "Rule activation", "Top attack types",
                                  "Prediction trends"])
    with t1:
        for n in ("Mamdani", "Sugeno"):
            m = R_[n]["m"]
            fig = go.Figure(go.Bar(x=list(m), y=list(m.values()), marker_color=CYAN if n == "Mamdani" else PURPLE,
                                   text=[f"{v:.3f}" for v in m.values()], textposition="outside"))
            show(style(fig, f"{n} model performance (test file)", 360, xtitle="Metric", ytitle="Value (0-1)"))
        a, b = st.columns(2)
        with a:
            show(confusion_figure(R_["Mamdani"]["c"], "Confusion matrix: Mamdani"))
        with b:
            show(confusion_figure(R_["Sugeno"]["c"], "Confusion matrix: Sugeno"))
    with t2:
        long = pd.concat([pd.DataFrame({"Risk": ev["test"][k + "_risk"].values, "Model": n, "Actual": test["actual"].values})
                          for n, k in (("Mamdani", "mamdani"), ("Sugeno", "sugeno"))])
        fig = px.histogram(long, x="Risk", color="Actual", facet_col="Model", barmode="overlay", nbins=50, opacity=0.7,
                           color_discrete_map={"Normal": GREEN, "Attack": RED})
        show(style(fig, "Intrusion risk score distribution by true class (test file)", 450, xtitle="Risk score", ytitle="Records"))
    with t3:
        mfire = pd.DataFrame(ev["m_fire"], columns=[r["id"] for r in st.session_state["rules"]])
        mfire["family"] = test["family"].values
        heat = mfire.groupby("family").mean()
        fig = px.imshow(heat.round(2), text_auto=True, aspect="auto", color_continuous_scale=[[0, "#0b1230"], [1, CYAN]])
        show(style(fig, "Average Mamdani rule activation per true traffic family (test file)", 480,
                   xtitle="Rule", ytitle="True family"))
        st.caption("Bright cells show which rules fire for which kind of traffic: e.g. D-rules for DoS, P-rules for Probe, "
                   "N-rules for Normal.")
    with t4:
        top = test[test["actual"] == "Attack"]["attack_name"].value_counts().head(15).reset_index()
        top.columns = ["Attack", "Records"]
        top["Seen in training"] = top["Attack"].isin(set(train["attack_name"]))
        fig = px.bar(top, x="Attack", y="Records", color="Seen in training", text_auto=True,
                     color_discrete_map={True: CYAN, False: RED})
        show(style(fig, "Most frequent attack types in the test file", 420, xtitle="Attack type", ytitle="Records"))
    with t5:
        h = st.session_state["history"]
        if len(h) == 0:
            st.info("No monitor data yet. Stream records in the Live Monitor or submit predictions first.")
        else:
            h = h.copy()
            h["Mamdani alerts (rolling 20)"] = (h["mamdani_class"] != "Normal").rolling(20, min_periods=1).sum()
            h["Sugeno alerts (rolling 20)"] = (h["sugeno_class"] != "Normal").rolling(20, min_periods=1).sum()
            fig = px.line(h, x="event", y=["Mamdani alerts (rolling 20)", "Sugeno alerts (rolling 20)"],
                          color_discrete_sequence=[CYAN, PURPLE])
            show(style(fig, "Alerts over time (rolling window of 20 events)", 420, xtitle="Event number", ytitle="Alerts in window"))


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def main():
    st.set_page_config(page_title="Fuzzy IDS", page_icon="🛡️", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)
    init_state()
    if not (os.path.exists(TRAIN_PATH) and os.path.exists(TEST_PATH)):
        st.error("Dataset not found. Place KDDTrain_.txt and KDDTest_.txt inside the 'data' folder next to app.py.")
        st.stop()
    cfg = config_json(st.session_state["mfs"], st.session_state["rules"])
    ev = evaluate_config(cfg)

    with st.sidebar:
        st.markdown("## 🛡️ Fuzzy IDS")
        st.caption("Mamdani & Sugeno fuzzy logic · NSL-KDD")
        page = st.radio("Navigation", ["Dataset Overview", "Rules & Membership", "Mamdani vs Sugeno",
                                       "Prediction", "Live Monitor", "Analytics"], label_visibility="collapsed")
        st.divider()
        st.markdown("**Decision borders**")
        st.checkbox("Use borders tuned on validation data", value=True, key="use_tuned")
        if not st.session_state["use_tuned"]:
            for k in ("mamdani", "sugeno"):
                t = ev["thr"][k]
                st.slider(f"{k.title()}: Normal | Suspicious | Malicious", 0, 100, (int(t[0]), int(t[1])), key="thr_" + k)
        else:
            for k in ("mamdani", "sugeno"):
                t = ev["thr"][k]
                st.caption(f"{k.title()}: Normal < {t[0]:.0f} <= Suspicious < {t[1]:.0f} <= Malicious")
        st.checkbox("Count 'Suspicious' as an alert in evaluation", value=True, key="susp_alert")
        st.divider()
        st.caption("Only fuzzy logic is used: no machine-learning models.")

    pages = {"Dataset Overview": page_overview, "Rules & Membership": page_rules, "Mamdani vs Sugeno": page_compare,
             "Prediction": page_predict, "Live Monitor": page_monitor, "Analytics": page_analytics}
    pages[page](ev)


if __name__ == "__main__":
    main()
